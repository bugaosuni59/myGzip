#include "my.cpp"
long t1=0;
long t2=0;

