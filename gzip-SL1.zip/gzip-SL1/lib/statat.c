#include <config.h>
#define STATAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"
