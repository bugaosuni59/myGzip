//
// Created by bugaosuni59 on 18-12-21.
//

#ifndef GZIP_1_9_MY_H
#define GZIP_1_9_MY_H
#include <bits/stdc++.h>
#include <sys/time.h>
using namespace std;
extern long t1;
extern long t2;
//extern struct timeval t1;
//extern struct timeval t2;
//extern struct timeval t3;

#endif //GZIP_1_9_MY_H
